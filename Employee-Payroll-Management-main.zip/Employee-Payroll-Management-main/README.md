The Employee-Payroll-Management built using oops and in which you can add,remove and display employees.</br>
The OOP's Concepts are used : </br>
i. Inheritance
ii. Polymorphism
iii. Abstraction
iv. Encapsulation

For storage of Employees ArrayList has been used.
